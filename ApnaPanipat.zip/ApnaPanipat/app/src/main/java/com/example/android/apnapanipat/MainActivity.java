package com.example.android.apnapanipat;

import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.design.widget.TabLayout;

public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ViewPager viewpager = (ViewPager)findViewById(R.id.viewpager);//creating object of viewpager and connecting it to xml file. viewpager is to slide over fragments
        FixedTabPagerAdapter adapter = new FixedTabPagerAdapter(this,getSupportFragmentManager());//this will help to direct over the pages made by fragment
        viewpager.setAdapter(adapter);//adding adapter to the viewpager
        //this will help us navigating around fragments as it tells tab heading
        TabLayout Tablayout = findViewById(R.id.tabs);
        Tablayout.setupWithViewPager(viewpager);
    }
}
