package com.example.android.apnapanipat;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

/**
 * Created by Dell on 03-11-2018.
 */

public class WordAdapter extends ArrayAdapter {
    public WordAdapter(@NonNull Context context, ArrayList<festivalEvents> festivals, int textViewResourceId) {
        super(context, 0, festivals);
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {

        if (convertView==null)
        {
            convertView= LayoutInflater.from(getContext()).inflate(R.layout.listview,parent,false);
        }

        festivalEvents currentWord = (festivalEvents) getItem(position);

        TextView Heading = convertView.findViewById(R.id.F_name);
        ImageView Photo = convertView.findViewById(R.id.FesImage);
        TextView Content = convertView.findViewById(R.id.F_content);

        Heading.setText(currentWord.getFheading());
        Photo.setImageResource(currentWord.getFimgId());
        Content.setText(currentWord.getFcontent());
        return convertView;
    }
}
