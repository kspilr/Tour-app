package com.example.android.apnapanipat;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;

import java.util.ArrayList;


public class Restaurants extends Fragment {

    public Restaurants() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.listview,container,false);
        final ArrayList<festivalEvents> Arr_restaurants = new ArrayList<>();
        Arr_restaurants.add(new festivalEvents(R.string.H_Attr1,R.mipmap.nathus,R.string.Cnathu));
        Arr_restaurants.add(new festivalEvents(R.string.H_Attr1,R.mipmap.hive,R.string.Chive));
        WordAdapter adapter = new WordAdapter(getActivity(),Arr_restaurants,0);
        ListView listView = (ListView) rootView.findViewById(R.id.list);
        listView.setAdapter(adapter);
        return rootView;
    }
}
