package com.example.android.apnapanipat;

/**
 * Created by Dell on 02-11-2018.
 */

public class festivalEvents
{
    private int Fheading,FimgId,Fcontent;
    public int getFheading() {
        return Fheading;
    }
    public festivalEvents(int heading,int imgid,int content)
    {
        Fheading=heading;
        FimgId=imgid;
        Fcontent=content;
    }
    public int getFcontent() {
        return Fcontent;
    }
    public int getFimgId() {
        return FimgId;
    }
}
