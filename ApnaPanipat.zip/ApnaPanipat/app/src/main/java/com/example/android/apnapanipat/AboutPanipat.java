package com.example.android.apnapanipat;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.util.ArrayList;


public class AboutPanipat extends Fragment {
    public AboutPanipat() {}
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View rootView = inflater.inflate(R.layout.listview, container, false);

        final ArrayList<festivalEvents> infoPnp= new ArrayList<festivalEvents>();
        infoPnp.add(new festivalEvents(R.string.H_Attr11,R.mipmap.pnp,R.string.Cpnp));


        return rootView;
    }

}
