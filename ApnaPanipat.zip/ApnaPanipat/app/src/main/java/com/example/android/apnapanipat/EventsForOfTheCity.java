package com.example.android.apnapanipat;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;

import android.view.ViewGroup;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;

/**
 * A simple {@link Fragment} subclass.
 */
public class EventsForOfTheCity extends Fragment {
    public EventsForOfTheCity() {
        // Required empty public constructor
    }
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.listview, container, false);

        final ArrayList<festivalEvents> festivals= new ArrayList<festivalEvents>();

        festivals.add(new festivalEvents(R.string.H_Attr5,R.mipmap.baisakhi,R.string.Cbaisakhi));
        festivals.add(new festivalEvents(R.string.H_Attr6,R.mipmap.dussehra,R.string.Cdusshera));
        festivals.add(new festivalEvents(R.string.H_Attr7,R.mipmap.gangaur,R.string.Cgangaur));
        festivals.add(new festivalEvents(R.string.H_Attr8,R.mipmap.gugga_navmi,R.string.CgugaNavmi));
        festivals.add(new festivalEvents(R.string.H_Attr9,R.mipmap.lohri,R.string.Clohri));
        festivals.add(new festivalEvents(R.string.H_Attr10,R.mipmap.teej,R.string.Cteej));

        WordAdapter adapter = new WordAdapter(getActivity(),festivals,0);

        ListView listView = (ListView) rootView.findViewById(R.id.list);

        listView.setAdapter(adapter);
        return rootView;
    }

}
