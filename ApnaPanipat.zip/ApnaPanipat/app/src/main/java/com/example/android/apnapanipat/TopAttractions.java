package com.example.android.apnapanipat;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;

/**
 * A simple {@link Fragment} subclass.
 */
public class TopAttractions extends Fragment {

    public TopAttractions() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.listview,container,false);
        final ArrayList<festivalEvents> Arr_attractions = new ArrayList<>();
        Arr_attractions.add(new festivalEvents(R.string.H_Attr1,R.mipmap.bulleshah,R.string.Cbulleshah));
        Arr_attractions.add(new festivalEvents(R.string.H_Attr2,R.mipmap.pnpmeseum,R.string.CPnpMuseum));
        WordAdapter adapter = new WordAdapter(getActivity(),Arr_attractions,0);
        ListView listView = (ListView) rootView.findViewById(R.id.list);
        listView.setAdapter(adapter);
        return rootView;

    }
}
