package com.example.android.apnapanipat;

import android.content.Context;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;

/**
 * Created by Dell on 01-11-2018.
 */

public class FixedTabPagerAdapter extends FragmentPagerAdapter {

    private Context pcontext;
    public FixedTabPagerAdapter(Context context, FragmentManager fm) {
        super(fm);
        pcontext=context;
    }

    @Override
    public Fragment getItem(int position) {
        switch (position)
        {
            case 0:
                return new AboutPanipat();
            case 1:
                return new TopAttractions();
            case 2:
                return new Restaurants();
            case 3:
                return new EventsForOfTheCity();

            default:
                return null;
        }

    }

    @Nullable
    @Override
    public CharSequence getPageTitle(int position) {
        switch (position)
        {
            case 0:
                return "About";
            case 1:
                return "Attractions Of City";
            case 2:
                return "Hotels & Restaurants";
            case 3:

                return "Events For The City";
                default:
                    return null;
        }
    }

    @Override
    public int getCount() {
        return 5;
    }
}
